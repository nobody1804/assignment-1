const apiUrl = 'https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json';

fetch(apiUrl)
  .then(response => {
    // Check if the request was successful
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    // Parse the response body as JSON
    return response.json();
  })
  .then(data => {
    for (i = 1; i < data.categories.length+1; i++) {
        var test = document.getElementById('tabHeader'+i);
        test.innerHTML = data.categories[i-1].category_name;
        /* data.categories.forEach(item => {
            console.log(item.category_products);
            if(item.category_products.length > 0){
                console.log(item, i);
                var imageElements = document.getElementById('men'+i);
                imageElements.src = item.category_products[i].image;
            }
        }); */  
    }   
    data.categories.forEach(item => {
        console.log(item);
        if(item.category_name === 'Men'){           
            for (i = 1; i < item?.category_products.length+1; i++) {            
                var imageElements = document.getElementById('men'+i);
                // var imageElements1 = document.getElementById('women'+i);
                imageElements.src = item.category_products[i-1].image;
                // imageElements1.src = item.category_products[i-1].image;

            }
        } else if(item.category_name === 'Women'){          
            for (i = 1; i < item?.category_products.length+2; i++) {            
                var imageElements = document.getElementById('women'+i);
                // var imageElements1 = document.getElementById('women'+i);
                imageElements.src = item.category_products[i-1].image;
                // imageElements1.src = item.category_products[i-1].image;

            }

        } else {
            console.log('kids');
        }
    });


  })
  .catch(error => {
    // Handle any errors that occurred during the fetch
    console.error('Fetch error:', error);
  });
  
  
    function openTab(evt, tabName) {
      // Hide all tab contents
      var i, tabcontent, tablinks;
      tabcontent = document.getElementsByClassName("tabcontent");
      for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
      }
      
      // Remove 'active' class from all tab buttons
      tablinks = document.getElementsByClassName("tablinks");
      for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
      }
      
      // Show the clicked tab content and mark the button as active
      document.getElementById(tabName).style.display = "block";
      // Function to open a specific tab by clicking
      evt.currentTarget.classList.add("active");
    }